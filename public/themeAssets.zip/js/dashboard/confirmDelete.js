$(".confirm").on("submit", function () {
    return confirm("Are you sure?");
});